require("aeslua")

local enc = aeslua.encrypt("password", "super secret stuff")
print(enc)

local dec = aeslua.decrypt("password", enc)
print(dec)
